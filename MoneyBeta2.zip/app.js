const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const money = (n) => new Intl.NumberFormat('zh-TW',{style:'currency',currency:'TWD',maximumFractionDigits:0}).format(Number(n)||0);
const today = () => new Date().toISOString().slice(0,10);
const ym = () => today().slice(0,7);
const uid = () => crypto.randomUUID ? crypto.randomUUID() : String(Date.now()+Math.random());

const expenseCats = ['🍱 餐飲','☕ 飲料','🛒 購物','🚗 交通','🏠 房租','📱 通訊','💊 醫療','🎁 娛樂','🐶 毛孩','📦 其他'];
const incomeCats = ['💰 薪水','💵 獎金','❤️ 共同收入','🎁 禮金','📈 投資','📦 其他'];
const storeKey = 'moneyBeta2Data';
let state = JSON.parse(localStorage.getItem(storeKey) || 'null') || { transactions: [], assets: [], goals: [] };
let filter = 'all';

function save(){ localStorage.setItem(storeKey, JSON.stringify(state)); render(); }
function sum(arr){ return arr.reduce((a,b)=>a+(Number(b.amount)||0),0); }
function sameMonth(t){ return (t.date||'').slice(0,7) === ym(); }
function byDate(a,b){ return (b.date||'').localeCompare(a.date||'') || b.createdAt - a.createdAt; }

function setCats(){
  const type = $('#transactionForm select[name="type"]').value;
  $('#categorySelect').innerHTML = (type==='income'?incomeCats:expenseCats).map(c=>`<option>${c}</option>`).join('');
}

function openModal(id){
  const dialog = $('#'+id);
  if(id==='transactionModal') { $('#transactionForm input[name="date"]').value = today(); setCats(); }
  dialog.showModal();
}

function showPage(id){
  $$('.page').forEach(p=>p.classList.toggle('active', p.id===id));
  $$('.nav').forEach(n=>n.classList.toggle('active', n.dataset.page===id));
  const names = {dashboardPage:'首頁',recordsPage:'記帳',assetsPage:'資產',goalsPage:'存錢目標',statsPage:'統計',settingsPage:'設定'};
  $('#pageTitle').textContent = names[id] || '首頁';
  window.scrollTo({top:0,behavior:'smooth'});
}

function render(){
  const monthTx = state.transactions.filter(sameMonth);
  const monthIncome = sum(monthTx.filter(t=>t.type==='income'));
  const monthExpense = sum(monthTx.filter(t=>t.type==='expense'));
  $('#monthIncome').textContent = money(monthIncome);
  $('#monthExpense').textContent = money(monthExpense);
  $('#personalAssets').textContent = money(sum(state.assets.filter(a=>a.owner==='personal')));
  $('#sharedAssets').textContent = money(sum(state.assets.filter(a=>a.owner==='shared')));
  renderRecords(); renderAssets(); renderGoals(); renderStats();
}

function txItem(t){
  const sign = t.type === 'income' ? '+' : '-';
  const payer = t.payer ? `・代墊：${t.payer}` : '';
  return `<div class="item"><div><b>${t.category} ${t.note || (t.wallet==='shared'?'共用紀錄':'個人紀錄')}</b><div class="meta">${t.date}・${t.wallet==='shared'?'共用金':'我的帳本'}・${t.method}${payer}</div></div><div><b class="amount ${t.type}">${sign}${money(t.amount)}</b><button class="delete" data-del-tx="${t.id}">刪除</button></div></div>`;
}

function renderRecords(){
  const sorted = [...state.transactions].sort(byDate);
  $('#recentList').innerHTML = sorted.slice(0,5).map(txItem).join('') || '<p class="empty">還沒有記帳，先新增第一筆吧！</p>';
  const rows = sorted.filter(t=>filter==='all'||t.wallet===filter);
  $('#recordList').innerHTML = rows.map(txItem).join('') || '<p class="empty">這裡還沒有紀錄。</p>';
}

function renderAssets(){
  $('#assetList').innerHTML = state.assets.map(a=>`<div class="item"><div><b>${a.kind}｜${a.name}</b><div class="meta">${a.owner==='shared'?'共用金':'我的資產'}</div></div><div><b>${money(a.amount)}</b><button class="delete" data-del-asset="${a.id}">刪除</button></div></div>`).join('') || '<p class="empty">還沒有資產，新增現金、銀行或電子支付吧！</p>';
}

function goalCard(g){
  const pct = Math.min(100, Math.round((Number(g.current)||0)/(Number(g.target)||1)*100));
  return `<div class="item"><div style="flex:1"><b>${g.name}</b><div class="meta">目前 ${money(g.current)} / 目標 ${money(g.target)}，剩餘 ${money(Math.max(0,g.target-g.current))}</div><div class="track"><div class="fill" style="width:${pct}%"></div></div></div><div><b>${pct}%</b><button class="delete" data-del-goal="${g.id}">刪除</button></div></div>`;
}

function renderGoals(){
  $('#goalPreview').innerHTML = state.goals[0] ? goalCard(state.goals[0]) : '還沒有目標，去新增一個吧！';
  $('#goalList').innerHTML = state.goals.map(goalCard).join('') || '<p class="empty">還沒有存錢目標。</p>';
}

function categoryBars(target, data){
  const entries = Object.entries(data).sort((a,b)=>b[1]-a[1]);
  const total = sum(entries.map(e=>({amount:e[1]})));
  target.innerHTML = entries.map(([k,v])=>`<div class="bar"><div class="bar-top"><span>${k}</span><b>${money(v)}</b></div><div class="track"><div class="fill" style="width:${total?Math.round(v/total*100):0}%"></div></div></div>`).join('') || '<p class="empty">本月還沒有支出資料。</p>';
}

function renderStats(){
  const monthExpenseTx = state.transactions.filter(t=>sameMonth(t)&&t.type==='expense');
  const cat = {};
  monthExpenseTx.forEach(t=>cat[t.category]=(cat[t.category]||0)+Number(t.amount));
  categoryBars($('#categoryBars'), cat);
  categoryBars($('#statCategory'), cat);
  const adv = {慧慈:0, 仲凱:0};
  state.transactions.filter(t=>t.wallet==='shared'&&t.type==='expense'&&t.payer).forEach(t=>adv[t.payer]=(adv[t.payer]||0)+Number(t.amount));
  const diff = (adv['慧慈']||0) - (adv['仲凱']||0);
  let settle = '目前兩人代墊差不多。';
  if(diff>0) settle = `仲凱需補給慧慈 ${money(diff/2)}。`;
  if(diff<0) settle = `慧慈需補給仲凱 ${money(Math.abs(diff)/2)}。`;
  $('#advanceStats').innerHTML = `<div class="item"><div><b>慧慈代墊</b><div class="meta">${money(adv['慧慈']||0)}</div></div><div><b>仲凱代墊</b><div class="meta">${money(adv['仲凱']||0)}</div></div></div><p class="empty">${settle}</p>`;
  renderCalendar(monthExpenseTx);
}

function renderCalendar(tx){
  const [y,m] = ym().split('-').map(Number);
  const days = new Date(y,m,0).getDate();
  const data = {};
  tx.forEach(t=>{ const d=Number(t.date.slice(8,10)); data[d]=(data[d]||0)+Number(t.amount); });
  $('#calendarStats').innerHTML = Array.from({length:days},(_,i)=>`<div class="day">${i+1}<small>${data[i+1]?money(data[i+1]).replace('NT',''):''}</small></div>`).join('');
}

function addSeed(){
  if(!confirm('加入範例資料？不會刪除你原本資料。')) return;
  state.assets.push({id:uid(),owner:'personal',kind:'銀行',name:'個人帳戶',amount:28600},{id:uid(),owner:'shared',kind:'銀行',name:'共用帳戶',amount:15000});
  state.goals.push({id:uid(),name:'日本旅行',target:52000,current:12800});
  state.transactions.push(
    {id:uid(),createdAt:Date.now(),wallet:'personal',type:'income',category:'💰 薪水',method:'銀行',amount:28000,date:today(),note:'本月薪水',payer:''},
    {id:uid(),createdAt:Date.now(),wallet:'personal',type:'expense',category:'🍱 餐飲',method:'現金',amount:120,date:today(),note:'午餐',payer:''},
    {id:uid(),createdAt:Date.now(),wallet:'shared',type:'expense',category:'🍱 餐飲',method:'LINE Pay',amount:850,date:today(),note:'晚餐',payer:'慧慈'}
  );
  save();
}

$$('[data-page]').forEach(btn=>btn.addEventListener('click',()=>showPage(btn.dataset.page)));
$$('[data-open]').forEach(btn=>btn.addEventListener('click',()=>openModal(btn.dataset.open)));
$('#transactionForm select[name="type"]').addEventListener('change', setCats);
$('#transactionForm').addEventListener('submit', e=>{ e.preventDefault(); const f=new FormData(e.target); state.transactions.push({id:uid(),createdAt:Date.now(),wallet:f.get('wallet'),type:f.get('type'),category:f.get('category'),method:f.get('method'),payer:f.get('payer'),date:f.get('date'),note:f.get('note'),amount:Number(f.get('amount'))}); e.target.reset(); $('#transactionModal').close(); save(); });
$('#assetForm').addEventListener('submit', e=>{ e.preventDefault(); const f=new FormData(e.target); state.assets.push({id:uid(),owner:f.get('owner'),kind:f.get('kind'),name:f.get('name'),amount:Number(f.get('amount'))}); e.target.reset(); $('#assetModal').close(); save(); });
$('#goalForm').addEventListener('submit', e=>{ e.preventDefault(); const f=new FormData(e.target); state.goals.push({id:uid(),name:f.get('name'),target:Number(f.get('target')),current:Number(f.get('current'))}); e.target.reset(); $('#goalModal').close(); save(); });
$$('.chip').forEach(c=>c.addEventListener('click',()=>{ $$('.chip').forEach(x=>x.classList.remove('active')); c.classList.add('active'); filter=c.dataset.filter; renderRecords(); }));
document.addEventListener('click', e=>{ const t=e.target; if(t.dataset.delTx){state.transactions=state.transactions.filter(x=>x.id!==t.dataset.delTx);save()} if(t.dataset.delAsset){state.assets=state.assets.filter(x=>x.id!==t.dataset.delAsset);save()} if(t.dataset.delGoal){state.goals=state.goals.filter(x=>x.id!==t.dataset.delGoal);save()} });
$('#seedBtn').addEventListener('click', addSeed);
$('#exportBtn').addEventListener('click',()=>{ const blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='money-beta2-backup.json'; a.click(); URL.revokeObjectURL(a.href); });
$('#importFile').addEventListener('change', async e=>{ const file=e.target.files[0]; if(!file) return; try{ state=JSON.parse(await file.text()); save(); alert('匯入完成'); }catch{ alert('檔案格式錯誤'); }});
$('#clearBtn').addEventListener('click',()=>{ if(confirm('確定清除所有資料？')){ state={transactions:[],assets:[],goals:[]}; save(); }});
setCats(); render();
